import pandas as pd
import ast
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

def plot_grid_load_from_csv(csv_path):
    """
    Plots the grid load against capacity constraints with improved readability by splitting
    into two separate plots:
    1. First plot: Load, supply, demand, and adjusted load
    2. Second plot: Aggregate storage level and rate of change

    Parameters:
        csv_path (str): Path to the CSV file containing the solver output data.
    """
    # Load data from CSV
    data = pd.read_csv(csv_path)

    # Ensure required columns are in the CSV
    required_columns = ['Time Step', 'Load', 'Supply', 'Demand', 'Storage Level']
    for col in required_columns:
        if col not in data.columns:
            raise ValueError(f"Missing required column '{col}' in CSV file.")

    # Extract data
    time_steps = data['Time Step']
    load_values = data['Load']
    adjusted_load_values = data['Adjusted Load']
    supply_values = data['Supply']
    demand_values = data['Demand']
    storage_level = data['Storage Level']

    # Parse the 'Storage Level' column as dictionaries with error handling
    def parse_storage_entry(entry):
        try:
            if pd.notna(entry) and entry != '{}':
                return ast.literal_eval(entry)
            else:
                return {}
        except (ValueError, SyntaxError):
            return {}

    storage_dicts = storage_level.apply(parse_storage_entry)

    # Calculate aggregate storage level and rate of change
    total_storage_level = storage_dicts.apply(lambda d: sum(d.values()))  # Sum levels across storage units
    change_in_storage_level = total_storage_level.diff().fillna(0)  # Compute rate of change

    # Determine color for each time step based on constraint check
    colors = [
        "green" if supply_values[i] >= load_values[i] >= demand_values[i] else "red"
        for i in range(len(time_steps))
    ]

    # Create a figure with two subplots
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(50, 15), sharex=True)

    # PLOT 1: Load, Supply, Demand, and Adjusted Load
    ax1.set_title("Grid Load vs. Capacity Constraints")

    # Plot supply and demand constraints
    ax1.plot(time_steps, supply_values, label='Supply Constraint', color='blue', linestyle='--')
    ax1.plot(time_steps, demand_values, label='Demand Constraint', color='orange', linestyle='--')
    ax1.plot(time_steps, adjusted_load_values, label='Adjusted Load', color='lightgreen', linestyle='-')

    # Plot load with color-coded segments based on constraint status
    for i in range(len(time_steps) - 1):
        ax1.plot(time_steps[i:i + 2], load_values[i:i + 2], color=colors[i], linewidth=2)

    # Add a small representative segment to the legend for the color-coded load
    ax1.plot([], [], color='green', linewidth=2, label='Load (Within Constraints)')
    ax1.plot([], [], color='red', linewidth=2, label='Load (Exceeds Constraints)')

    ax1.set_ylabel("Load / Capacity")
    ax1.legend(loc='best')
    ax1.grid(True, alpha=0.3)

    # PLOT 2: Storage Level and Change in Storage Level
    ax2.set_title("Aggregate Storage Level and Rate of Change")

    # Plot total storage level
    ax2.plot(time_steps, total_storage_level, label='Aggregate Storage Level',
             color='darkgoldenrod', linewidth=2)

    # Create a second y-axis for the change in storage level
    ax3 = ax2.twinx()
    ax3.plot(time_steps, change_in_storage_level, label='Change in Storage Level',
             color='black', linestyle=':', linewidth=1.5)

    # Set labels and legends
    ax2.set_xlabel("Time Step")
    ax2.set_ylabel("Storage Level")
    ax3.set_ylabel("Change in Storage Level")

    # Add legends to both axes
    lines1, labels1 = ax2.get_legend_handles_labels()
    lines2, labels2 = ax3.get_legend_handles_labels()
    ax2.legend(lines1 + lines2, labels1 + labels2, loc='best')

    ax2.grid(True, alpha=0.3)

    # Adjust layout and display
    plt.tight_layout()
    plt.show()

    return fig, (ax1, ax2, ax3)  # Return figure and axes for potential further customization

def visualize_individual_storage_behavior(csv_path):
    """
    Visualizes individual energy storage behavior with one graph per storage unit.
    Activities are directly retrieved from the solver's output.

    Parameters:
        csv_path (str): Path to the output CSV from the solver run.
    """
    # Load the CSV
    data = pd.read_csv(csv_path)

    # Parse relevant columns
    data['Storage Mutations'] = data['Storage Mutation'].apply(ast.literal_eval)
    data['Load Mutations'] = data['Load Mutations'].apply(ast.literal_eval)
    data['Storage Levels'] = data['Storage Level'].apply(ast.literal_eval)
    data['Activities'] = data['Activity Types'].apply(ast.literal_eval)  # Convert string to dict
    data['Electricity Price'] = data['Electricity Price']
    average_price = data['Electricity Price'].mean()

    # Extract unique storage units
    storage_units = set()
    for storage_levels in data['Storage Levels']:
        storage_units.update(storage_levels.keys())

    # Define activity colors
    activity_colors = {
        'Load management': 'red',
        'SOC_balancing_charge': 'blue',
        'SOC_balancing_discharge': 'cyan',
        'price_optimization_charge': 'lightgreen',
        'price_optimization_discharge': 'darkgreen',
        'idle': 'gray'
    }

    # Loop through each storage unit
    for storage_name in storage_units:
        activities = []
        energy_values = []
        price_values = []
        times = []

        for _, row in data.iterrows():
            soc_level = row['Storage Levels'].get(storage_name, 0)
            electricity_price = row['Electricity Price']
            activity = row['Activities'].get(storage_name, 'idle')  # Default to 'idle'

            activities.append(activity)
            energy_values.append(soc_level)
            price_values.append(electricity_price)
            times.append(row.name)  # Use the index as the time step

        # Map activities to colors
        colors = [activity_colors.get(activity, 'gray') for activity in activities]

        # Create a new plot for the storage unit
        fig, ax = plt.subplots(figsize=(12, 6))
        ax.set_title(f"Energy Storage Behavior: {storage_name}")

        # Plot the storage level with color-coded segments
        for i in range(1, len(times)):
            ax.plot(
                [times[i - 1], times[i]],
                [energy_values[i - 1], energy_values[i]],
                color=colors[i],
                linewidth=2,
            )

        # Plot electricity price
        ax2 = ax.twinx()
        ax2.plot(times, price_values, color='gray', linestyle='--', label='Electricity Price')
        ax2.axhline(average_price, color='black', linestyle='-', label='Average Price')

        # Add labels, legends, and format the plot
        ax.set_xlabel("Time Step")
        ax.set_ylabel("Energy (kWh)")
        ax2.set_ylabel("Electricity Price (€)")
        ax.legend(handles=[
            plt.Line2D([0], [0], color='red', label='Load Management'),
            plt.Line2D([0], [0], color='blue', label='SOC Balancing (Charge)'),
            plt.Line2D([0], [0], color='cyan', label='SOC Balancing (Discharge)'),
            plt.Line2D([0], [0], color='green', label='Price Optimization'),
            plt.Line2D([0], [0], color='gray', label='Idle')
        ], loc="upper left")
        ax2.legend(loc="upper right")

        plt.tight_layout()
        plt.show()

def visualize_combined_storage_behavior(csv_path):
    """
    Visualizes combined energy storage behavior in one graph.
    Activities are directly retrieved from the solver's output.

    Parameters:
        csv_path (str): Path to the output CSV from the solver run.
    """
    import ast
    import matplotlib.pyplot as plt
    import pandas as pd

    # Load the CSV
    data = pd.read_csv(csv_path)

    # Parse relevant columns
    data['Storage Mutations'] = data['Storage Mutation'].apply(ast.literal_eval)
    data['Load Mutations'] = data['Load Mutations'].apply(ast.literal_eval)
    data['Storage Levels'] = data['Storage Level'].apply(ast.literal_eval)
    data['Activities'] = data['Activity Types'].apply(ast.literal_eval)  # Convert string to dict
    data['Electricity Price'] = pd.to_numeric(data['Electricity Price'], errors='coerce')  # Ensure numeric prices
    average_price = data['Electricity Price'].mean()

    # Extract unique storage units
    storage_units = set()
    for storage_levels in data['Storage Levels']:
        storage_units.update(storage_levels.keys())

    # Define activity colors
    activity_colors = {
        'Load management': 'red',
        'SOC_balancing_charge': 'blue',
        'SOC_balancing_discharge': 'cyan',
        'price_optimization': 'green',
        'idle': 'gray'
    }

    # Create the combined plot
    fig, ax = plt.subplots(figsize=(14, 8))
    ax.set_title("Combined Energy Storage Behavior")
    ax.set_xlabel("Time Step")
    ax.set_ylabel("Energy (kWh)")

    # Plot electricity price
    ax2 = ax.twinx()
    ax2.plot(data.index, data['Electricity Price'], color='gray', linestyle='--', label='Electricity Price')
    ax2.axhline(average_price, color='black', linestyle='-', label='Average Price')
    ax2.set_ylabel("Electricity Price (€)")

    # Plot each storage unit's behavior
    for storage_name in storage_units:
        activities = []
        energy_values = []
        times = []

        for _, row in data.iterrows():
            soc_level = row['Storage Levels'].get(storage_name, 0)
            activity = row['Activities'].get(storage_name, 'idle')  # Default to 'idle'

            activities.append(activity)
            energy_values.append(soc_level)
            times.append(row.name)  # Use the index as the time step

        # Map activities to colors
        colors = [activity_colors.get(activity, 'gray') for activity in activities]

        # Plot the storage level with color-coded segments
        for i in range(1, len(times)):
            ax.plot(
                [times[i - 1], times[i]],
                [energy_values[i - 1], energy_values[i]],
                color=colors[i],  # Use the current time step’s activity color
                linewidth=2,
                label=storage_name if i == 1 else ""  # Add legend only for the first segment
            )

    # Add legends and format the plot
    ax.legend(loc="upper left", title="Storage Units")
    ax2.legend(loc="upper right")
    plt.tight_layout()
    plt.show()
