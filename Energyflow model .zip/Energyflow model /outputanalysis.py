import pandas as pd
import json


def parse_json_field(field):
    """
    Safely parse a JSON-like string field, handling empty or malformed inputs.
    """
    try:
        if pd.isna(field) or field == "{}":
            return {}
        # Convert single quotes to double quotes to conform to JSON standard
        return json.loads(field.replace("'", '"'))
    except Exception as e:
        return {}


def analyze_storage_cycles(df, column):
    """
    Analyze storage cycles (charge to discharge transitions) for storage assets.
    Also, count the amount of energy lost due to the inefficiencies of the storage units.
    The energy lost is computed as the difference between the load (from column index 1) and the actual charge,
    only during charging events.
    """
    storage_cycles = {}
    energy_losses = {}

    for index, row in df.iterrows():
        current_states = parse_json_field(row[column])
        if index > 0:
            previous_states = parse_json_field(df.loc[index - 1, column])
            for asset, value in current_states.items():
                if asset not in storage_cycles:
                    storage_cycles[asset] = 0
                if asset not in energy_losses:
                    energy_losses[asset] = 0
                if asset in previous_states:
                    # Detect transition from charge to discharge or vice versa
                    if (value > 0 and previous_states[asset] <= 0) or (value < 0 and previous_states[asset] >= 0):
                        storage_cycles[asset] += 1
                        # If charging, compute energy lost as the difference between the intended load (column 1) and the actual charge
                        if value > 0:
                            try:
                                load_value = float(row[1])  # Convert the intended load to float
                            except ValueError:
                                load_value = 0
                            loss = max(load_value - value, 0)
                            energy_losses[asset] += loss

    return storage_cycles, energy_losses


def analyze_charge_cycles(df, state_column):
    """
    Count charge cycles per asset based on state transitions.
    """
    charge_cycles = {}
    previous_states = {}

    for index, row in df.iterrows():
        current_states = parse_json_field(row[state_column])
        for asset, state in current_states.items():
            if asset not in charge_cycles:
                charge_cycles[asset] = 0
            if asset in previous_states:
                if state == "SOC_balancing_charge" and previous_states[asset] != "SOC_balancing_charge":
                    charge_cycles[asset] += 1
            previous_states[asset] = state

    return charge_cycles


def analyze_curtailment_certainty(df, curtailment_column):
    """
    Calculate the certainty you don't have to curtail (proportion of timesteps with no curtailment).
    Also calculates the curtailment cost per grid user and returns the sum of the total curtailment cost.
    """
    no_curtailment_count = 0
    total_count = len(df)
    curtailment_costs = {}
    total_curtailment_cost = 0

    for index, row in df.iterrows():
        curtailment_data = parse_json_field(row[curtailment_column])
        if isinstance(curtailment_data, dict):
            # Check if there is no curtailment for all users in this timestep
            if all(user_data.get("curtailment_amount", 0) == 0 for user_data in curtailment_data.values()):
                no_curtailment_count += 1
            # Accumulate curtailment cost per grid user and overall
            for user, user_data in curtailment_data.items():
                cost = user_data.get("curtailment_cost", 0)
                curtailment_costs[user] = curtailment_costs.get(user, 0) + cost
                total_curtailment_cost += cost
        else:
            # If the field is not a dict, assume no curtailment
            no_curtailment_count += 1

    certainty = no_curtailment_count / total_count
    return certainty, curtailment_costs, total_curtailment_cost


def analyze_flexibility_needs(df, state_column):
    """
    Count the number of times flexibility measures are needed.
    """
    flexibility_count = 0
    for index, row in df.iterrows():
        current_states = parse_json_field(row[state_column])
        if any(state in ["Load management", "price_optimization_discharge"] for state in current_states.values()):
            flexibility_count += 1
    return flexibility_count


def analyze_constraint_status(df, status_column):
    """
    Count the number of timesteps where the constraint status is "not ok".
    Since each timestep is 60 minutes, return the result as (hours not ok)/(year),
    assuming a 8760-hour year.
    """
    not_ok_count = 0
    for index, row in df.iterrows():
        # Convert to string, strip any whitespace, and compare in lowercase
        status = str(row[status_column]).strip().lower()
        if status == "not ok":
            not_ok_count += 1
    return f"{not_ok_count} / 8760"


def analyze_heat_gas_loads(df):
    """
    Analyze heat and gas loads from both storage and source/sink.
    Returns:
    - Sum of gas/heat loads from storage
    - Sum of gas/heat loads from source/sink
    - Ratio of total load to sink load for each medium
    """
    # Column indices based on the CSV structure after skipping the header row:
    # 17: Total Gas Load, 18: Gas Load from Storage, 19: Gas Load from Sink
    # 20: Total Heat Load, 21: Heat Load from Storage, 22: Heat Load from Sink
    gas_load_from_storage_col = 18  # "Gas Load from Storage"
    gas_load_from_sink_col = 19  # "Gas Load from Sink"
    total_gas_load_col = 17  # "Total Gas Load"

    heat_load_from_storage_col = 21  # "Heat Load from Storage"
    heat_load_from_sink_col = 22  # "Heat Load from Sink"
    total_heat_load_col = 20  # "Total Heat Load"

    # Calculate sums
    gas_load_from_storage_sum = df[gas_load_from_storage_col].astype(float).sum()
    gas_load_from_sink_sum = df[gas_load_from_sink_col].astype(float).sum()
    total_gas_load_sum = df[total_gas_load_col].astype(float).sum()

    heat_load_from_storage_sum = df[heat_load_from_storage_col].astype(float).sum()
    heat_load_from_sink_sum = df[heat_load_from_sink_col].astype(float).sum()
    total_heat_load_sum = df[total_heat_load_col].astype(float).sum()

    # Calculate ratios
    gas_ratio = total_gas_load_sum / gas_load_from_sink_sum if gas_load_from_sink_sum != 0 else float('inf')
    heat_ratio = total_heat_load_sum / heat_load_from_sink_sum if heat_load_from_sink_sum != 0 else float('inf')

    return {
        "gas_load_from_storage_sum": gas_load_from_storage_sum,
        "gas_load_from_sink_sum": gas_load_from_sink_sum,
        "gas_load_ratio": gas_ratio,
        "heat_load_from_storage_sum": heat_load_from_storage_sum,
        "heat_load_from_sink_sum": heat_load_from_sink_sum,
        "heat_load_ratio": heat_ratio
    }


def analyze_average_loads(df):
    """
    Calculate the average of the original load and adjusted load.
    """
    load_col = 1  # "Load" column
    adjusted_load_col = 2  # "Adjusted Load" column

    average_load = df[load_col].astype(float).mean()
    average_adjusted_load = df[adjusted_load_col].astype(float).mean()

    return {
        "average_load": average_load,
        "average_adjusted_load": average_adjusted_load
    }


def analyze_heat_load_vs_conversion(df, conversion_column=15, total_heat_load_col=20):
    """
    Count the number of timesteps where the total heat load (column 20) is less than or equal to
    the heat provided by the conversion mutations (column 15).

    It tries to extract a numeric value from the conversion mutations. If a key "heat" exists, it is used.
    Otherwise, it sums any numeric values in the conversion mutations dictionary.
    Returns the count and the proportion of such timesteps.
    """
    count = 0
    total_rows = len(df)

    for index, row in df.iterrows():
        conversion_data = parse_json_field(row[conversion_column])
        heat_conversion = 0
        if isinstance(conversion_data, dict):
            if "heat" in conversion_data:
                try:
                    heat_conversion = float(conversion_data["heat"])
                except Exception:
                    heat_conversion = 0
            else:
                # Sum all numeric values found in the dictionary
                for key, value in conversion_data.items():
                    try:
                        heat_conversion += float(value)
                    except Exception:
                        pass

        try:
            total_heat_load = float(row[total_heat_load_col])
        except Exception:
            total_heat_load = 0

        if total_heat_load <= heat_conversion:
            count += 1

    proportion = count / total_rows if total_rows > 0 else 0
    return count, proportion


# --- New Functions for Electric Energy and Cost Analysis --- #

def calculate_total_electric_energy_use(df):
    """
    Calculate total electric energy use by summing the Adjusted Load (column index 2).
    """
    return df[2].astype(float).sum()


def calculate_electricity_cost(df):
    """
    Calculate total electricity cost by multiplying Adjusted Load (column 2) by Electricity Price (column 13)
    for each time step and summing the results.
    """
    adjusted_load = df[2].astype(float)
    electricity_price = df[13].astype(float)
    return (adjusted_load * electricity_price).sum()


def get_total_gas_and_heat_use(df):
    """
    Return the total gas and heat use from the last timestep's Sink/Source Mutations (column index 16).
    The field is expected to be a JSON-like string that tracks cumulative usage.
    """
    last_sink_source = parse_json_field(df[16].iloc[-1])
    total_gas_use = last_sink_source.get("gasSinkSource", 0)
    total_heat_use = last_sink_source.get("heatSinkSource", 0)
    return total_gas_use, total_heat_use


def main(csv_file):
    # Skip the header row (the first row) so that it doesn't become part of the data.
    df = pd.read_csv(csv_file, header=None, skiprows=1)

    # Specify column indices for JSON fields based on the provided CSV structure:
    # 0: Time Step, 1: Load, 2: Adjusted Load, 3: Supply, 4: Demand,
    # 5: Constraint Status, 6: Available Cap Supply, 7: Available Cap Demand,
    # 8: Storage Mutation, 9: Load Mutations, 10: Storage Level,
    # 11: Extra Flexibility Required, 12: Curtailment, 13: Electricity Price,
    # 14: Activity Types, 15: Conversion Mutations, 16: Sink/Source Mutations
    # 17: Total Gas Load, 18: Gas Load from Storage, 19: Gas Load from Sink
    # 20: Total Heat Load, 21: Heat Load from Storage, 22: Heat Load from Sink
    storage_column = 9  # e.g., Load Mutations column
    curtailment_column = 12  # Curtailment column (index 12)
    state_column = 15  # e.g., Conversion Mutations column
    constraint_status_column = 5  # Constraint Status column

    # Analyze existing metrics
    storage_cycles, energy_losses = analyze_storage_cycles(df, storage_column)
    charge_cycles = analyze_charge_cycles(df, state_column)
    curtailment_certainty, curtailment_costs, total_curtailment_cost = analyze_curtailment_certainty(
        df, curtailment_column)
    flexibility_needs = analyze_flexibility_needs(df, state_column)
    constraint_status_result = analyze_constraint_status(df, constraint_status_column)

    # New analyses: Heat & Gas Loads, Load Averages, and Heat vs Conversion
    heat_gas_metrics = analyze_heat_gas_loads(df)
    load_metrics = analyze_average_loads(df)
    heat_conversion_count, heat_conversion_proportion = analyze_heat_load_vs_conversion(df)

    # New calculations: Electric energy use, Electricity cost, Total gas and heat use from sink/source
    total_electric_energy = calculate_total_electric_energy_use(df)
    total_electricity_cost = calculate_electricity_cost(df)
    total_gas_use, total_heat_use = get_total_gas_and_heat_use(df)

    # Print results from previous analyses
    print("Storage Cycles:", storage_cycles)
    print("Energy Lost due to Inefficiencies:", energy_losses)
    print("Charge Cycles:", charge_cycles)
    print("Certainty of No Curtailment:", curtailment_certainty)
    print("Curtailment Costs per Grid User:", curtailment_costs)
    print("Total Curtailment Cost:", total_curtailment_cost)
    print("Flexibility Needs:", flexibility_needs)
    print("Constraint Status ('not ok') per Year:", constraint_status_result)

    print("\n--- Heat and Gas Load Analysis ---")
    print(f"Sum of Gas Load from Storage: {heat_gas_metrics['gas_load_from_storage_sum']:.2f}")
    print(f"Sum of Gas Load from Sink: {heat_gas_metrics['gas_load_from_sink_sum']:.2f}")
    print(f"Ratio of Total Gas Load to Gas from Sink: {heat_gas_metrics['gas_load_ratio']:.4f}")
    print(f"Sum of Heat Load from Storage: {heat_gas_metrics['heat_load_from_storage_sum']:.2f}")
    print(f"Sum of Heat Load from Sink: {heat_gas_metrics['heat_load_from_sink_sum']:.2f}")
    print(f"Ratio of Total Heat Load to Heat from Sink: {heat_gas_metrics['heat_load_ratio']:.4f}")

    print("\n--- Load Analysis ---")
    print(f"Average Load: {load_metrics['average_load']:.2f}")
    print(f"Average Adjusted Load: {load_metrics['average_adjusted_load']:.2f}")

    # print("\n--- Heat Load vs Conversion Mutations ---")
    # print(f"Timesteps where Total Heat Load <= Heat Provided by Conversion: {heat_conversion_count}")
    # print(f"Proportion of such timesteps: {heat_conversion_proportion:.4f}")

    # Print new electric energy and cost metrics
    print("\n--- Electric Energy and Cost Analysis ---")
    print(f"Total Electric Energy Use (Adjusted Load): {total_electric_energy:.2f}")
    print(f"Total Electricity Cost: {total_electricity_cost:.2f}")

    # Print total gas and heat use from the sink/source
    print("\n--- Total Gas and Heat Use from Sink/Source ---")
    print(f"Total Gas Use: {total_gas_use}")
    print(f"Total Heat Use: {total_heat_use}")


if __name__ == "__main__":
    csv_file = "Objectdata/GridUserdata/Output files/old runs /basetestoneautoconfig.csv"
    main(csv_file)
