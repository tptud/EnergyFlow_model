import csv
from Objects import (
    load_grid_users,
    load_electrical_grid,
    load_shared_energy_storage,
    load_sink_source,
    load_conversion_units
)
from vizualizesolveroutput import (
    plot_grid_load_from_csv,
    visualize_individual_storage_behavior,
    visualize_combined_storage_behavior
)

from outputanalysis import main



# Load data and setup for experiments
path_to_user_load_profile = "Objectdata/GridUserdata/Loadprofiles"
path_to_grid_profiles = "Objectdata/GridUserdata/Loadprofiles"
path_to_grid_points = "Objectdata/GridUserdata/objectinfo/ElectricalGrid base 1-10.csv"
electrical_grids = load_electrical_grid(path_to_grid_points, path_to_grid_profiles)
sinks_sources = load_sink_source()


# --- RUN Validation Verification use ---
# path_to_grid_users = "Objectdata/GridUserdata/objectinfo/veriGridUser .csv"
# path_to_storage_csv = "Objectdata/GridUserdata/objectinfo/veriSharedEnergyStorage .csv"
# path_to_conversion_csv = "Objectdata/GridUserdata/objectinfo/veriConversionUnit  .csv"
# csv_path = "Objectdata/GridUserdata/Output files/old runs /runverification_output.csv"  # Name of the experiment file
# electrical_grid_node = electrical_grids[1]

# -------------------------------
# EXPERIMENT RUN CONFIGURATIONS
# -------------------------------

# --- RUN 1 ---
# path_to_grid_users = "Objectdata/GridUserdata/objectinfo/GridUser 1-5 .csv"
# path_to_storage_csv = "Objectdata/GridUserdata/objectinfo/SharedEnergyStorage 1,2,4,10  empty.csv"
# path_to_conversion_csv = "Objectdata/GridUserdata/objectinfo/ConversionUnit 1 - 8, 10.csv"
# csv_path = "Objectdata/GridUserdata/Output files/old runs /run1.1_output.csv"  # Name of the experiment file
# electrical_grid_node = electrical_grids[0]

# --- RUN 2 ---
# path_to_grid_users = "Objectdata/GridUserdata/objectinfo/GridUser 1-5 .csv"
# path_to_storage_csv = "Objectdata/GridUserdata/objectinfo/SharedEnergyStorage 1,2,4,10  empty.csv"
# path_to_conversion_csv = "Objectdata/GridUserdata/objectinfo/ConversionUnit 1 - 8, 10.csv"
# csv_path = "Objectdata/GridUserdata/Output files/old runs /run2_output.csv"
# electrical_grid_node = electrical_grids[1]

# --- RUN 3 ---
# path_to_grid_users = "Objectdata/GridUserdata/objectinfo/GridUser 1-5 .csv"
# path_to_storage_csv = "Objectdata/GridUserdata/objectinfo/SharedEnergyStorage 3,5-7,9 .csv"
# path_to_conversion_csv = "Objectdata/GridUserdata/objectinfo/ConversionUnit 1 - 8, 10.csv"
# csv_path = "Objectdata/GridUserdata/Output files/old runs /run3_output.csv"
# electrical_grid_node = electrical_grids[1]

# --- RUN 4 ---
# path_to_grid_users = "Objectdata/GridUserdata/objectinfo/GridUser 1-5 .csv"
# path_to_storage_csv = "Objectdata/GridUserdata/objectinfo/SharedEnergyStorage 1,2,4,10  empty.csv"
# path_to_conversion_csv = "Objectdata/GridUserdata/objectinfo/ConversionUnit 1 - 8, 10.csv"
# csv_path = "Objectdata/GridUserdata/Output files/old runs /run4_output.csv"
# electrical_grid_node = electrical_grids[1]

# --- RUN 5 ---
# path_to_grid_users = "Objectdata/GridUserdata/objectinfo/GridUser 1-5 .csv"
# path_to_storage_csv = "Objectdata/GridUserdata/objectinfo/SharedEnergyStorage 3,5-7,9 .csv"
# path_to_conversion_csv = "Objectdata/GridUserdata/objectinfo/ConversionUnit 1 - 8, 10.csv"
# csv_path = "Objectdata/GridUserdata/Output files/old runs /run5_output.csv"
# electrical_grid_node = electrical_grids[1]

# --- RUN 6 ---
path_to_grid_users = "Objectdata/GridUserdata/objectinfo/GridUser 6 - 8  A truck.csv"
path_to_storage_csv = "Objectdata/GridUserdata/objectinfo/SharedEnergyStorage 3,5-7,9 .csv"
path_to_conversion_csv = "Objectdata/GridUserdata/objectinfo/ConversionUnit 1 - 8, 10.csv"
csv_path = "Objectdata/GridUserdata/Output files/old runs /run6.1_output0.3curtailA.csv"
electrical_grid_node = electrical_grids[1]

# --- RUN 7 ---
# path_to_grid_users = "Objectdata/GridUserdata/objectinfo/GridUser 6 - 8  A truck.csv"
# path_to_storage_csv = "Objectdata/GridUserdata/objectinfo/SharedEnergyStorage 3,5-7,9 .csv"
# path_to_conversion_csv = "Objectdata/GridUserdata/objectinfo/ConversionUnit 1 - 8, 10.csv"
# csv_path = "Objectdata/GridUserdata/Output files/old runs /run7_output.csv"
# electrical_grid_node = electrical_grids[1]

# --- RUN 8 ---
# path_to_grid_users = "Objectdata/GridUserdata/objectinfo/GridUser 6 - 8  A truck.csv"
# path_to_storage_csv = "Objectdata/GridUserdata/objectinfo/SharedEnergyStorage 8 .csv"
# path_to_conversion_csv = "Objectdata/GridUserdata/objectinfo/ConversionUnit 1 - 8, 10.csv"
# csv_path = "Objectdata/GridUserdata/Output files/old runs /run8_output.csv"
# electrical_grid_node = electrical_grids[1]

# --- RUN 9 ---
# path_to_grid_users = "Objectdata/GridUserdata/objectinfo/GridUser 9-10 .csv"
# path_to_storage_csv = "Objectdata/GridUserdata/objectinfo/SharedEnergyStorage 3,5-7,9 .csv"
# path_to_conversion_csv = "Objectdata/GridUserdata/objectinfo/ConversionUnit 9 .csv"
# csv_path = "Objectdata/GridUserdata/Output files/old runs /run9b_output.csv"
# electrical_grid_node = electrical_grids[1]

# --- RUN 10 ---
# path_to_grid_users = "Objectdata/GridUserdata/objectinfo/GridUser 9-10 .csv"
# path_to_storage_csv = "Objectdata/GridUserdata/objectinfo/SharedEnergyStorage 1,2,4,10  empty.csv"
# path_to_conversion_csv = "Objectdata/GridUserdata/objectinfo/ConversionUnit 1 - 8, 10.csv"
# csv_path = "Objectdata/GridUserdata/Output files/old runs /run10_output.csv"
# electrical_grid_node = electrical_grids[2]

# ---------------------------------
# EXAMPLE: Activate RUN 1 by removing the '#' in front:
# path_to_grid_users = "Objectdata/GridUserdata/objectinfo/GridUser 1-5.csv"
# path_to_storage_csv = "Objectdata/GridUserdata/objectinfo/SharedEnergyStorage 1.csv"
# path_to_conversion_csv = "Objectdata/GridUserdata/objectinfo/ConversionUnit 1-8.csv"


# Load data from configurations set above
grid_users = load_grid_users(path_to_grid_users, path_to_user_load_profile)
shared_storage_units = load_shared_energy_storage(path_to_storage_csv)
conversion_units = load_conversion_units(path_to_conversion_csv)



def process_auxiliary_medium_load(time_step, grid_users, medium, storage_units, sink_sources):
    """
    Processes the auxiliary load for a given medium (e.g., 'gas' or 'heat').

    For the specified medium:
      1. Sum the total load from grid users (assumed to be in a column like 'gas_load' or 'heat_load').
      2. Use stored energy from the corresponding storage unit first.
      3. If storage is insufficient, withdraw the deficit from the sink/source (recorded as a negative mutation).

    Returns a tuple: (total_load, provided_by_storage, deficit_from_sink)
    """
    load_column = f"{medium}_load"
    total_load = sum(
        user.load_profile.loc[time_step, load_column]
        for user in grid_users if load_column in user.load_profile.columns
    )
    provided = 0
    deficit = total_load  # initially, assume full deficit

    # Find the storage unit for the given medium (assumes one per medium)
    storage_unit = None
    for s in storage_units:
        if s.medium == medium:
            storage_unit = s
            break

    # Find the sink/source object for the given medium
    sink = None
    for s in sink_sources:
        if s.medium == medium:
            sink = s
            break

    if storage_unit:
        if storage_unit.current_storage >= total_load:
            storage_unit.current_storage -= total_load
            provided = total_load
            deficit = 0
        else:
            provided = storage_unit.current_storage
            deficit = total_load - provided
            storage_unit.current_storage = 0

    if deficit > 0 and sink:
        # Record a negative mutation on the sink/source (withdraw deficit)
        sink.mutation -= deficit
        sink.current_sum -= deficit

    return total_load, provided, deficit


def solver(time_step, grid, grid_users, storage_units):
    # Process auxiliary loads (gas and heat) separately.
    total_gas_load, gas_from_storage, gas_deficit = process_auxiliary_medium_load(
        time_step, grid_users, 'gas', storage_units, sinks_sources
    )
    total_heat_load, heat_from_storage, heat_deficit = process_auxiliary_medium_load(
        time_step, grid_users, 'heat', storage_units, sinks_sources
    )

    # Process electricity load.
    user_load_sum = calculate_grid_load(grid_users, time_step)
    supply, demand = get_grid_constraints(grid, time_step)
    # Note: The time offset for electricity price can be adjusted as needed.
    electricity_price = grid.load_profile.loc[
        grid.load_profile['time'] == time_step + 1, 'electricity_price'
    ].values[0]

    available_cap_supply = supply - user_load_sum
    available_cap_demand = demand - user_load_sum
    constraint_status = "ok" if supply >= user_load_sum >= demand else "not ok"
    adjusted_load = user_load_sum
    flex_required = 0

    storage_mutations = {}
    load_mutations = {}
    conversion_mutations = {}
    curtailment = {}

    # Electricity flexibility management if constraints are not met.
    if constraint_status == "not ok":
        flex_required = available_cap_demand if available_cap_demand > 0 else available_cap_supply

        # Use stored electricity first.
        for storage in storage_units:
            if storage.medium != 'electricity' or flex_required == 0:
                continue
            storage_mutation, load_mutation = storage.manage_flexibility(flex_required)
            storage.used_this_step = True
            storage.activity = "Load management"
            flex_required -= load_mutation
            adjusted_load += load_mutation
            storage_mutations[storage.name] = storage_mutation
            load_mutations[storage.name] = load_mutation

        available_cap_supply = supply - adjusted_load
        available_cap_demand = demand - adjusted_load
        constraint_status = "ok" if supply >= adjusted_load >= demand else "not ok"

        if constraint_status == "not ok" and flex_required != 0:
            flex_required, adjusted_load, conversion_mutations, _, storage_mutations = conversion_flex(
                flex_required, conversion_units, storage_units, sinks_sources, adjusted_load,
                conversion_mutations, {}, storage_mutations
            )
            constraint_status = "ok" if supply >= adjusted_load >= demand else "not ok"

        if constraint_status == "not ok" and flex_required != 0:
            flex_required, curtailment = curtailment_process(time_step, flex_required, grid_users)
            total_curtailment_amount = sum(
                user_data['curtailment_amount'] for user_data in curtailment.values()
            )
            adjusted_load += total_curtailment_amount
            available_cap_supply = supply - adjusted_load
            available_cap_demand = demand - adjusted_load
            constraint_status = "ok" if supply >= adjusted_load >= demand else "not ok"

    if constraint_status == "ok":
        handle_result = handle_extra_grid_capacity(
            time_step, grid, grid_users, storage_units,
            user_load_sum, adjusted_load, supply, demand,
            available_cap_supply, available_cap_demand,
            constraint_status, flex_required, storage_mutations, load_mutations, conversion_mutations
        )
        result = {**handle_result,
                  'curtailment': curtailment,
                  'electricity_price': electricity_price,
                  # Include auxiliary load details in the output.
                  'total_gas_load': total_gas_load,
                  'gas_load_from_storage': gas_from_storage,
                  'gas_load_from_sink': gas_deficit,
                  'total_heat_load': total_heat_load,
                  'heat_load_from_storage': heat_from_storage,
                  'heat_load_from_sink': heat_deficit}
        return result

    # Fallback response in case of error.
    return {
        'time_step': time_step,
        'load': user_load_sum,
        'adjusted_load': adjusted_load,
        'supply': supply,
        'demand': demand,
        'constraint_status': constraint_status,
        'available_cap_supply': available_cap_supply,
        'available_cap_demand': available_cap_demand,
        'storage_mutations': storage_mutations,
        'load_mutations': load_mutations,
        'storage_levels': {storage.name: storage.current_storage for storage in storage_units},
        'flexibility_required': flex_required,
        'curtailment': curtailment,
        'electricity_price': electricity_price,
        'activity_types': {storage.name: storage.activity for storage in storage_units},
        'conversion_mutations': conversion_mutations,
        'sink_source_mutations': {sink.name: sink.mutation for sink in sinks_sources},
        'total_gas_load': total_gas_load,
        'gas_load_from_storage': gas_from_storage,
        'gas_load_from_sink': gas_deficit,
        'total_heat_load': total_heat_load,
        'heat_load_from_storage': heat_from_storage,
        'heat_load_from_sink': heat_deficit,
    }


def handle_extra_grid_capacity(
        time_step, grid, grid_users, storage_units,
        user_load_sum, adjusted_load, supply, demand,
        available_cap_supply, available_cap_demand,
        constraint_status, flex_required, storage_mutations, load_mutations, conversion_mutations):
    """
    Handles extra grid capacity by charging/discharging electricity storage to balance state-of-charge.
    """
    electricity_price = grid.load_profile.loc[
        grid.load_profile['time'] == time_step * 1, 'electricity_price'
    ].values[0]
    average_price = grid.load_profile['electricity_price'].mean()

    for storage in storage_units:
        if storage.used_this_step or storage.medium != 'electricity':
            continue

        if electricity_price < (
                average_price * storage.storage_efficiency) and storage.current_storage < storage.maximum_level * storage.energy_capacity:
            desired_charge = min((storage.maximum_level * storage.energy_capacity) - storage.current_storage,
                                 available_cap_supply)
            charge_amount, load_mutation = storage.charge(available_cap_supply)
            if load_mutation > 0:
                adjusted_load += load_mutation
                available_cap_supply = supply - adjusted_load
                storage_mutations[storage.name] = charge_amount
                load_mutations[storage.name] = load_mutation
                storage.activity = "price_optimization_charge"
                storage.used_this_step = True

        elif electricity_price > average_price and storage.current_storage > storage.minimum_level * storage.energy_capacity:
            desired_discharge = min(storage.current_storage - (storage.minimum_level * storage.energy_capacity),
                                    abs(available_cap_demand))
            discharge_amount, load_mutation = storage.discharge(desired_discharge)
            if load_mutation < 0:
                adjusted_load += load_mutation
                available_cap_demand = demand - adjusted_load
                storage_mutations[storage.name] = discharge_amount
                load_mutations[storage.name] = load_mutation
                storage.activity = "price_optimization_discharge"
                storage.used_this_step = True

        if available_cap_supply > 0 and storage.current_storage < storage.maximum_level * storage.energy_capacity:
            desired_charge = min((storage.maximum_level * storage.energy_capacity) - storage.current_storage,
                                 available_cap_supply)
            actual_charge, load_mutation = storage.charge(desired_charge)
            if actual_charge > 0:
                adjusted_load += load_mutation
                available_cap_supply = supply - adjusted_load
                storage_mutations[storage.name] = actual_charge
                load_mutations[storage.name] = load_mutation
                storage.used_this_step = True
                storage.activity = "SOC_balancing_charge"

        elif available_cap_demand < 0 and storage.current_storage > storage.minimum_level * storage.energy_capacity:
            desired_discharge = min(storage.current_storage - (storage.minimum_level * storage.energy_capacity),
                                    abs(available_cap_demand))
            actual_discharge, load_mutation = storage.discharge(desired_discharge)
            if actual_discharge < 0:
                load_mutations[storage.name] = load_mutation
                adjusted_load += load_mutation
                available_cap_demand = demand - adjusted_load
                storage_mutations[storage.name] = actual_discharge
                storage.used_this_step = True
                storage.activity = "SOC_balancing_discharge"

    return {
        'time_step': time_step,
        'load': user_load_sum,
        'adjusted_load': adjusted_load,
        'supply': supply,
        'demand': demand,
        'constraint_status': constraint_status,
        'available_cap_supply': available_cap_supply,
        'available_cap_demand': available_cap_demand,
        'storage_mutations': storage_mutations,
        'load_mutations': load_mutations,
        'storage_levels': {storage.name: storage.current_storage for storage in storage_units},
        'activity_types': {storage.name: storage.activity for storage in storage_units},
        'flexibility_required': flex_required,
        'conversion_mutations': conversion_mutations,
        'sink_source_mutations': {sink.name: sink.mutation for sink in sinks_sources},
    }


def conversion_flex(flex_required, conversion_units, shared_storage_units, sinks_sources, adjusted_load,
                    conversion_mutations, sink_source_mutations, storage_mutations):
    """
    Handles conversion flexibility for electricity.
    """
    flex_required = float(flex_required)
    for conversion_unit in conversion_units:
        input_medium = conversion_unit.input_medium
        output_medium_1 = conversion_unit.output_medium_1
        output_medium_2 = conversion_unit.output_medium_2

        if flex_required > 0 and input_medium == "electricity":  # If excess electricity in the system exists, it is converted to other energy forms.
            input_amount = min(flex_required,
                               conversion_unit.max_input_capacity)  # Checks how much electricity can be put in.
            conversion_unit.input_amount = input_amount
            conversion_unit.output_amount_medium_1 = input_amount * conversion_unit.conversion_rate_1
            conversion_unit.output_amount_medium_2 = input_amount * conversion_unit.conversion_rate_2
            conversion_mutations.setdefault(input_medium, 0)
            conversion_mutations[
                input_medium] -= input_amount  # save the change in a dict that tracks all the conversion changes.
            if output_medium_1:
                conversion_mutations.setdefault(output_medium_1, 0)
                conversion_mutations[output_medium_1] += conversion_unit.output_amount_medium_1
            if output_medium_2:
                conversion_mutations.setdefault(output_medium_2, 0)
                conversion_mutations[output_medium_2] += conversion_unit.output_amount_medium_2
            if conversion_unit.output_amount_medium_1 > 0:
                for storage_unit in shared_storage_units:
                    if storage_unit.medium == output_medium_1:
                        charge_amount, _ = storage_unit.charge(conversion_unit.output_amount_medium_1)
                        amount_to_sinksource = conversion_unit.output_amount_medium_1 - charge_amount
                        storage_mutations[storage_unit.name] = storage_mutations.get(storage_unit.name,
                                                                                     0) + charge_amount
                        sink_source_mutations.setdefault(output_medium_1, 0)
                        sink_source_mutations[output_medium_1] += amount_to_sinksource
                        for sink in sinks_sources:
                            if sink.medium == output_medium_1:
                                sink.mutation += amount_to_sinksource
                                sink.update_sum()
            if conversion_unit.output_amount_medium_2 > 0:
                for storage_unit in shared_storage_units:
                    if storage_unit.medium == output_medium_2:
                        charge_amount, _ = storage_unit.charge(conversion_unit.output_amount_medium_2)
                        amount_to_sinksource = conversion_unit.output_amount_medium_2 - charge_amount
                        storage_mutations[storage_unit.name] = storage_mutations.get(storage_unit.name,
                                                                                     0) + charge_amount
                        sink_source_mutations.setdefault(output_medium_2, 0)
                        sink_source_mutations[output_medium_2] += amount_to_sinksource
                        for sink in sinks_sources:
                            if sink.medium == output_medium_2:
                                sink.mutation += amount_to_sinksource
                                sink.update_sum()
            flex_required -= input_amount
            adjusted_load += input_amount

        elif flex_required < 0 and output_medium_1 == "electricity":  # If insufficient electricity in the system exists, it converts gas to electricity.
            desired_input_amount = abs(flex_required / conversion_unit.conversion_rate_1)
            input_amount = min(conversion_unit.max_input_capacity, desired_input_amount)
            conversion_unit.input_amount = input_amount
            conversion_unit.output_amount_medium_1 = input_amount * conversion_unit.conversion_rate_1
            conversion_unit.output_amount_medium_2 = input_amount * conversion_unit.conversion_rate_2

            # Track the output medium 1 (electricity)
            conversion_mutations.setdefault(output_medium_1, 0)
            conversion_mutations[output_medium_1] += conversion_unit.output_amount_medium_1

            # Track the input medium consumption
            if input_medium:
                conversion_mutations.setdefault(input_medium, 0)
                conversion_mutations[input_medium] -= input_amount

            # Handle the second output medium, likely heat
            if output_medium_2 and conversion_unit.output_amount_medium_2 > 0:
                conversion_mutations.setdefault(output_medium_2, 0)
                conversion_mutations[output_medium_2] += conversion_unit.output_amount_medium_2
                for storage_unit in shared_storage_units:
                    if storage_unit.medium == output_medium_2:
                        charge_amount, _ = storage_unit.charge(conversion_unit.output_amount_medium_2)
                        amount_to_sinksource = conversion_unit.output_amount_medium_2 - charge_amount
                        storage_mutations[storage_unit.name] = storage_mutations.get(storage_unit.name,
                                                                                     0) + charge_amount
                        sink_source_mutations.setdefault(output_medium_2, 0)
                        sink_source_mutations[output_medium_2] += amount_to_sinksource
                        for sink in sinks_sources:
                            if sink.medium == output_medium_2:
                                sink.mutation += amount_to_sinksource
                                sink.update_sum()

            # Get input medium from storage units if available
            amount_needed_from_sources = input_amount
            for storage_unit in shared_storage_units:
                if storage_unit.medium == input_medium and amount_needed_from_sources > 0:
                    discharge_amount, _ = storage_unit.discharge(-amount_needed_from_sources)
                    storage_mutations[storage_unit.name] = storage_mutations.get(storage_unit.name,
                                                                                 0) + discharge_amount
                    amount_needed_from_sources += discharge_amount  # discharge_amount is negative

            # Update flex_required with the actual electricity produced
            flex_required += conversion_unit.output_amount_medium_1

            # Update adjusted_load with the electricity produced
            adjusted_load -= conversion_unit.output_amount_medium_1

    return flex_required, adjusted_load, conversion_mutations, sink_source_mutations, storage_mutations


def curtailment_process(time_step, flex_required, grid_users):
    """
    Curtail grid users' electric loads to reduce flexibility requirements.
    """
    curtailment = {}
    sorted_users = sorted(grid_users, key=lambda user: user.curtailment_cost)
    for user in sorted_users:
        if flex_required == 0:
            break
        user.load_profile['electric_load'] = user.load_profile['electric_load'].astype(float)
        user_load = user.load_profile.loc[time_step, 'electric_load']
        if flex_required > 0 and user_load < 0:
            curtailment_amount = min(abs(user_load), abs(flex_required), user.curtailment_cap * abs(user_load))
            user.load_profile.loc[time_step, 'electric_load'] += curtailment_amount
            flex_required -= curtailment_amount
            curtailment[user.name] = {
                'curtailment_amount': curtailment_amount,
                'curtailment_cost': abs(curtailment_amount) * user.curtailment_cost
            }
        elif flex_required < 0 and user_load > 0:
            curtailment_amount = -min(abs(user_load), abs(flex_required), abs(user.curtailment_cap * user_load))
            user.load_profile.loc[time_step, 'electric_load'] += curtailment_amount
            flex_required -= curtailment_amount
            curtailment[user.name] = {
                'curtailment_amount': curtailment_amount,
                'curtailment_cost': curtailment_amount * user.curtailment_cost
            }
    return flex_required, curtailment


def calculate_grid_load(grid_users, time_step):
    """
    Calculates the total electric load from all grid users at the given time step.
    """
    user_load_sum = sum(user.load_profile.loc[time_step, 'electric_load'] for user in grid_users)
    return user_load_sum


def get_grid_constraints(grid, time_step):
    """
    Retrieves supply and demand constraints from the grid's load profile for the given time step.
    """
    constraint_row = grid.load_profile.loc[grid.load_profile['time'] == time_step * 1]
    if not constraint_row.empty:
        supply_value = constraint_row['external_constraint_supply_t'].values[0]
        demand_value = constraint_row['external_constraint_demand_t'].values[0]
        return supply_value, demand_value
    else:
        print(f"No data found for time step {time_step}.")
        return None, None


def save_solver_results(solver_results, filepath):
    with open(filepath, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow([
            'Time Step',
            'Load',
            'Adjusted Load',
            'Supply',
            'Demand',
            'Constraint Status',
            'Available Cap Supply',
            'Available Cap Demand',
            'Storage Mutation',
            'Load Mutations',
            'Storage Level',
            'Extra Flexibility Required',
            'Curtailment',
            'Electricity Price',
            'Activity Types',
            'Conversion Mutations',
            'Sink/Source Mutations',
            'Total Gas Load',
            'Gas Load from Storage',
            'Gas Load from Sink',
            'Total Heat Load',
            'Heat Load from Storage',
            'Heat Load from Sink'
        ])
        for result in solver_results:
            writer.writerow([
                result['time_step'],
                result['load'],
                result['adjusted_load'],
                result['supply'],
                result['demand'],
                result['constraint_status'],
                result['available_cap_supply'],
                result['available_cap_demand'],
                result['storage_mutations'],
                result['load_mutations'],
                result['storage_levels'],
                result['flexibility_required'],
                result['curtailment'],
                result['electricity_price'],
                result.get('activity_types', {}),
                result['conversion_mutations'],
                result['sink_source_mutations'],
                result['total_gas_load'],
                result['gas_load_from_storage'],
                result['gas_load_from_sink'],
                result['total_heat_load'],
                result['heat_load_from_storage'],
                result['heat_load_from_sink']
            ])


def display_solver_results(solver_run):
    print("Solver Run Results:")
    for step, values in solver_run.items():
        load = f"{values['load']:.1f}"
        supply = f"{values['supply']:.1f}"
        demand = f"{values['demand']:.1f}"
        available_cap_supply = f"{values['supply'] - values['load']:.1f}"
        available_cap_demand = f"{values['load'] - values['demand']:.1f}"
        constraint_ok = values.get('constraint?', 'N/A')
        print(
            f"Time Step {step}: Load = {load}, Supply = {supply}, Demand = {demand}, Constraint? = {constraint_ok}, "
            f"Available Cap Supply = {available_cap_supply}, Available Cap Demand = {available_cap_demand}"
        )


def _default_solver_response(time_step, load, storage_units, adjusted_load=None, supply=None, demand=None,
                             status="error", flex=0):
    return {
        'time_step': time_step,
        'load': load,
        'adjusted_load': adjusted_load if adjusted_load is not None else load,
        'supply': supply,
        'demand': demand,
        'constraint_status': status,
        'available_cap_supply': None,
        'available_cap_demand': None,
        'storage_mutations': {},
        'load_mutations': {},
        'storage_levels': {storage.name: storage.current_storage for storage in storage_units},
        'flexibility_required': flex,
        'curtailment': {},
        'activity_types': {storage.name: storage.activity for storage in storage_units},
        'conversion_mutations': {},
        'sink_source_mutations': {}
    }


def handle_conversion_with_flex(flex_required, conversion_units, shared_storage_units, sinks_sources, adjusted_load):
    conversion_mutations = {}
    load_mutations = {}
    storage_levels = {}
    for conversion_unit in conversion_units:
        input_medium = conversion_unit.input_medium
        if flex_required > 0:
            input_amount = min(flex_required, conversion_unit.max_input_capacity)
            conversion_unit.input_amount = input_amount
            flex_required -= input_amount
            outputs = []
            for idx, rate in enumerate([conversion_unit.conversion_rate_1, conversion_unit.conversion_rate_2], start=1):
                medium = getattr(conversion_unit, f"output_medium_{idx}")
                output_amount = input_amount * rate if medium else 0
                setattr(conversion_unit, f"output_amount_medium_{idx}", output_amount)
                if medium:
                    outputs.append((medium, output_amount))
            for medium, output_amount in outputs:
                if output_amount > 0:
                    if medium in shared_storage_units:
                        remaining = shared_storage_units[medium].charge(output_amount)[1]
                        if remaining > 0:
                            for sink_source in sinks_sources:
                                if sink_source.medium == medium:
                                    excess_to_store = min(remaining, sink_source.max_capacity - sink_source.current_sum)
                                    sink_source.mutation += excess_to_store
                                    sink_source.current_sum += excess_to_store
                                    remaining -= excess_to_store
                    else:
                        for sink_source in sinks_sources:
                            if sink_source.medium == medium:
                                excess_to_store = min(output_amount, sink_source.max_capacity - sink_source.current_sum)
                                sink_source.mutation += excess_to_store
                                sink_source.current_sum += excess_to_store
                    conversion_mutations[medium] = output_amount
        elif flex_required < 0:
            input_amount = -min(abs(flex_required), conversion_unit.max_input_capacity)
            conversion_unit.input_amount = input_amount
            flex_required += input_amount
            outputs = []
            for idx, rate in enumerate([conversion_unit.conversion_rate_1, conversion_unit.conversion_rate_2], start=1):
                medium = getattr(conversion_unit, f"output_medium_{idx}")
                output_amount = input_amount * rate if medium else 0
                setattr(conversion_unit, f"output_amount_medium_{idx}", output_amount)
                if medium:
                    outputs.append((medium, output_amount))
            for medium, output_amount in outputs:
                if output_amount > 0:
                    if medium in shared_storage_units:
                        remaining = shared_storage_units[medium].discharge(output_amount)[1]
                        if remaining < 0:
                            for sink_source in sinks_sources:
                                if sink_source.medium == medium:
                                    deficit_to_draw = min(abs(remaining),
                                                          sink_source.max_capacity + sink_source.current_sum)
                                    sink_source.mutation -= deficit_to_draw
                                    sink_source.current_sum -= deficit_to_draw
                                    remaining += deficit_to_draw
                    else:
                        for sink_source in sinks_sources:
                            if sink_source.medium == medium:
                                deficit_to_draw = min(output_amount, sink_source.max_capacity + sink_source.current_sum)
                                sink_source.mutation -= deficit_to_draw
                                sink_source.current_sum -= deficit_to_draw
                    conversion_mutations[medium] = -output_amount
        adjusted_load += conversion_unit.input_amount
        storage_levels = {name: storage.current_storage for name, storage in shared_storage_units.items()}
    return conversion_mutations, adjusted_load, flex_required, load_mutations, storage_levels


def run_solver(grid_users, grid, storage_units, num_steps=8669):
    solver_results = []
    for time_step in range(num_steps):
        # Reset storage usage for the current time step.
        for storage in storage_units:
            storage.reset_usage()
        result = solver(time_step, grid, grid_users, storage_units)
        solver_results.append(result)
    return solver_results


# Run the simulation and output results.
solver_run = run_solver(grid_users, electrical_grid_node, shared_storage_units)
save_solver_results(solver_run, csv_path)
plot_grid_load_from_csv(csv_path)
visualize_individual_storage_behavior(csv_path)
visualize_combined_storage_behavior(csv_path)
main(csv_file=csv_path)