import pandas as pd
import matplotlib.pyplot as plt

'''This code performs the preliminary analysis of the input load profiles'''

def load_individual_profiles(df, base_dir, show_plot=True):
    # Remove any whitespace or commas in the DataFrame column names
    df.columns = df.columns.str.replace(' ', '').str.replace(',', '')

    cumulative_electricity_load = pd.DataFrame()
    cumulative_heat_load = pd.DataFrame()
    load_file_column = 'electricity_demand_t'  # Assuming this column name for load profiles

    for user_index, user_loads_file in enumerate(df[load_file_column]):
        full_path = base_dir + str(user_loads_file)

        # Load each user's CSV file and standardize column names by stripping spaces and setting lowercase
        loaded_df = pd.read_csv(full_path, index_col='time')
        loaded_df.columns = loaded_df.columns.str.strip().str.lower()  # Standardize column names

        print(f"User {user_index} has load profile {user_loads_file}")
        print("Columns in loaded CSV:", loaded_df.columns)

        # Accumulate electricity and heat loads if columns exist
        if 'electric_load' in loaded_df.columns:
            if cumulative_electricity_load.empty:
                cumulative_electricity_load = loaded_df[['electric_load']].copy()
            else:
                cumulative_electricity_load['electric_load'] += loaded_df['electric_load']
        else:
            print(f"Warning: Column 'electric_load' not found in {user_loads_file}")

        if 'heat_load' in loaded_df.columns:
            if cumulative_heat_load.empty:
                cumulative_heat_load = loaded_df[['heat_load']].copy()
            else:
                cumulative_heat_load['heat_load'] += loaded_df['heat_load']
        else:
            print(f"Warning: Column 'heat_load' not found in {user_loads_file}")

        # Plot individual load profiles if desired
        if show_plot:
            if 'electric_load' in loaded_df.columns:
                plt.plot(loaded_df.index, loaded_df['electric_load'], label=f"{user_loads_file} electricity")
            if 'heat_load' in loaded_df.columns:
                plt.plot(loaded_df.index, loaded_df['heat_load'], label=f"{user_loads_file} heat")

    if show_plot:
        plt.xlabel("Time (hours)")
        plt.ylabel("Load")
        plt.title("Load Profiles for Individual Users")
        plt.legend()
        plt.show()

    print("Cumulative electricity load:\n", cumulative_electricity_load.head())
    print("Cumulative heat load:\n", cumulative_heat_load.head())

    return cumulative_electricity_load, cumulative_heat_load

def plot_cumulative_loads(cumulative_electricity_load, cumulative_heat_load):
    plt.figure(figsize=(12, 5))

    # Plot cumulative electricity load
    plt.subplot(1, 2, 1)
    if not cumulative_electricity_load.empty:
        cumulative_electricity_sum = cumulative_electricity_load['electric_load']
        plt.plot(cumulative_electricity_sum.index, cumulative_electricity_sum, label='Cumulative Electricity Load')
    plt.xlabel("Time (hours)")
    plt.ylabel("Cumulative Load (Electricity)")
    plt.title("Cumulative Electricity Load Profile for All Users")
    plt.legend()

    # Plot cumulative heat load
    plt.subplot(1, 2, 2)
    if not cumulative_heat_load.empty:
        cumulative_heat_sum = cumulative_heat_load['heat_load']
        plt.plot(cumulative_heat_sum.index, cumulative_heat_sum, label='Cumulative Heat Load', color='orange')
    plt.xlabel("Time (hours)")
    plt.ylabel("Cumulative Load (Heat)")
    plt.title("Cumulative Heat Load Profile for All Users")
    plt.legend()

    plt.tight_layout()
    plt.show()

def plot_individual_loads(df, base_dir):
    plt.figure(figsize=(16, 15))  # Increased height to accommodate 3 subplots

    # Plot 1: Electricity loads
    plt.subplot(3, 1, 1)  # Changed to 3 rows, 1 column, first plot
    plt.title("Electricity Load Profiles for Individual Users")
    for user_index, user_loads_file in enumerate(df['electricity_demand_t']):
        full_path = base_dir + str(user_loads_file)
        loaded_df = pd.read_csv(full_path, index_col='time')
        plt.plot(
            loaded_df.index,
            loaded_df['electric_load'],
            label=f"{user_loads_file}",
            alpha=0.5,
            linewidth=0.5
        )
    plt.xlabel("Time (hours)")
    plt.ylabel("Electricity Load")
    plt.legend()
    plt.grid()

    # Plot 2: Heat loads
    plt.subplot(3, 1, 2)  # Changed to 3 rows, 1 column, second plot
    plt.title("Heat Load Profiles for Individual Users")
    for user_index, user_loads_file in enumerate(df['electricity_demand_t']):
        full_path = base_dir + str(user_loads_file)
        loaded_df = pd.read_csv(full_path, index_col='time')
        plt.plot(
            loaded_df.index,
            loaded_df['heat_load'],
            label=f"{user_loads_file}",
            alpha=0.5,
            linewidth=0.5
        )
    plt.xlabel("Time (hours)")
    plt.ylabel("Heat Load")
    plt.legend()
    plt.grid()

    # Plot 3: Gas loads (new)
    plt.subplot(3, 1, 3)  # Added third subplot (3 rows, 1 column, third plot)
    plt.title("Gas Load Profiles for Individual Users")
    for user_index, user_loads_file in enumerate(df['electricity_demand_t']):
        full_path = base_dir + str(user_loads_file)
        loaded_df = pd.read_csv(full_path, index_col='time')
        plt.plot(
            loaded_df.index,
            loaded_df['gas_load'],
            label=f"{user_loads_file}",
            alpha=0.5,
            linewidth=0.5
        )
    plt.xlabel("Time (hours)")
    plt.ylabel("Gas Load")
    plt.legend()
    plt.grid()

    plt.tight_layout()
    plt.show()

def analyze_load_profiles(cumulative_electricity_load, cumulative_heat_load, individual_profiles_df=None,
                          base_dir=None):
    """
    Calculate descriptive statistics for electricity and heat load profiles
    and present them in a comparable table format.

    Parameters:
    -----------
    cumulative_electricity_load : pandas.DataFrame
        DataFrame containing cumulative electricity load data
    cumulative_heat_load : pandas.DataFrame
        DataFrame containing cumulative heat load data
    individual_profiles_df : pandas.DataFrame, optional
        DataFrame containing information about individual user profiles
    base_dir : str, optional
        Base directory where individual load profiles are stored

    Returns:
    --------
    pandas.DataFrame
        DataFrame containing descriptive statistics for both load types
    """
    import pandas as pd
    import numpy as np
    import matplotlib.pyplot as plt
    from tabulate import tabulate

    stats_data = {
        'Statistic': ['Mean', 'Median', 'Standard Deviation', 'Variance', 'Maximum', 'Minimum']
    }

    # Dictionary to map column names to actual file names
    column_to_filename = {}

    # Calculate statistics for cumulative electricity load
    if not cumulative_electricity_load.empty:
        elec_data = cumulative_electricity_load['electric_load']
        stats_data['Cumulative Electricity'] = [
            round(elec_data.mean(), 2),
            round(elec_data.median(), 2),
            round(elec_data.std(), 2),
            round(elec_data.var(), 2),
            round(elec_data.max(), 2),
            round(elec_data.min(), 2)
        ]
        column_to_filename['Cumulative Electricity'] = 'Cumulative Electricity'
    else:
        stats_data['Cumulative Electricity'] = ['N/A'] * 6
        column_to_filename['Cumulative Electricity'] = 'Cumulative Electricity'

    # Calculate statistics for cumulative heat load
    if not cumulative_heat_load.empty:
        heat_data = cumulative_heat_load['heat_load']
        stats_data['Cumulative Heat'] = [
            round(heat_data.mean(), 2),
            round(heat_data.median(), 2),
            round(heat_data.std(), 2),
            round(heat_data.var(), 2),
            round(heat_data.max(), 2),
            round(heat_data.min(), 2)
        ]
        column_to_filename['Cumulative Heat'] = 'Cumulative Heat'
    else:
        stats_data['Cumulative Heat'] = ['N/A'] * 6
        column_to_filename['Cumulative Heat'] = 'Cumulative Heat'

    # Create a DataFrame for the statistics
    stats_df = pd.DataFrame(stats_data)

    # If individual profiles information is provided, calculate stats for each profile
    if individual_profiles_df is not None and base_dir is not None:
        # Process individual load profiles if provided
        for user_index, user_loads_file in enumerate(individual_profiles_df['electricity_demand_t']):
            full_path = base_dir + str(user_loads_file)
            try:
                loaded_df = pd.read_csv(full_path, index_col='time')
                loaded_df.columns = loaded_df.columns.str.strip().str.lower()

                # Calculate statistics for individual electricity load
                if 'electric_load' in loaded_df.columns:
                    elec_data = loaded_df['electric_load']
                    column_name = f'User {user_index} Electricity'
                    stats_df[column_name] = [
                        round(elec_data.mean(), 2),
                        round(elec_data.median(), 2),
                        round(elec_data.std(), 2),
                        round(elec_data.var(), 2),
                        round(elec_data.max(), 2),
                        round(elec_data.min(), 2)
                    ]
                    column_to_filename[column_name] = f"{user_loads_file} (Elec)"

                # Calculate statistics for individual heat load
                if 'heat_load' in loaded_df.columns:
                    heat_data = loaded_df['heat_load']
                    column_name = f'User {user_index} Heat'
                    stats_df[column_name] = [
                        round(heat_data.mean(), 2),
                        round(heat_data.median(), 2),
                        round(heat_data.std(), 2),
                        round(heat_data.var(), 2),
                        round(heat_data.max(), 2),
                        round(heat_data.min(), 2)
                    ]
                    column_to_filename[column_name] = f"{user_loads_file} (Heat)"
            except Exception as e:
                print(f"Error processing file {user_loads_file}: {e}")

    # Display the statistics table
    print("\nDescriptive Statistics for Load Profiles:")
    print(tabulate(stats_df, headers='keys', tablefmt='fancy_grid', showindex=False))

    # Create bar plots for visual comparison
    plt.figure(figsize=(15, 10))

    # Extract relevant statistics
    stat_names = stats_df['Statistic'].tolist()
    columns_to_plot = [col for col in stats_df.columns if col != 'Statistic']

    # Create subplots for each statistic
    for i, stat in enumerate(['Mean', 'Maximum', 'Standard Deviation']):
        plt.subplot(1, 3, i + 1)
        stat_idx = stat_names.index(stat)

        # Get values and labels for the plot
        stat_values = [stats_df[col][stat_idx] for col in columns_to_plot]
        labels = [column_to_filename[col] for col in columns_to_plot]

        # Plot with actual filename labels
        bars = plt.bar(range(len(labels)), stat_values,
                       color=['blue' if 'Electricity' in col or 'Elec' in column_to_filename[col]
                              else 'orange' for col in columns_to_plot])

        plt.title(f"{stat} Values")
        plt.xticks(range(len(labels)), labels, rotation=45, ha='right')
        plt.ylabel(stat)
        plt.grid(axis='y', linestyle='--', alpha=0.7)

        # Add value labels on top of bars
        for bar in bars:
            height = bar.get_height()
            plt.text(bar.get_x() + bar.get_width() / 2., height + 0.02 * max(stat_values),
                     f'{height:.2f}',
                     ha='center', va='bottom', fontsize=8)

    plt.tight_layout()
    plt.subplots_adjust(bottom=0.25)  # Extra space for the rotated labels
    plt.show()

    return stats_df


# Load the CSV file into a DataFrame containing griduser info
df = pd.read_csv('Objectdata/GridUserdata/objectinfo/GridUser 6 - 8  A truck.csv')

# Relative file path for the load profiles, ensure each load profile matches number of users
base_dir = 'Objectdata/GridUserdata/Loadprofiles/'

# Load individual profiles
cumulative_electricity_load, cumulative_heat_load = load_individual_profiles(df, base_dir, show_plot=True)

# Plot cumulative load profiles for electricity and heat in one figure
plot_cumulative_loads(cumulative_electricity_load, cumulative_heat_load)

plot_individual_loads(df, base_dir)

# To include individual profiles in the analysis:
stats = analyze_load_profiles(cumulative_electricity_load, cumulative_heat_load, df, base_dir)
