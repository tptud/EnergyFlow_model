import pandas as pd
import os

class GridUser:
    """Represents a grid user with demand and curtailment parameters."""
    def __init__(self, name, electricity_demand_t, gas_energy_demand_t, heat_energy_demand_t, curtailment_cap,
                 curtailment_cost):
        self.name = name
        self.electricity_demand_t = electricity_demand_t
        self.gas_energy_demand_t = gas_energy_demand_t
        self.heat_energy_demand_t = heat_energy_demand_t
        self.curtailment_cap = curtailment_cap
        self.curtailment_cost = curtailment_cost
        self.load_profile = pd.DataFrame()  # Store time-dependent load profile

    def update_load_profile(self, load_profile_data):
        """Updates the load profile for the user."""
        self.load_profile = load_profile_data


class ElectricalGrid:
    """Represents an electrical grid point with constraints and pricing information."""
    def __init__(self, name, grid_electricity_demand_t, peak_grid_cap, external_constraint_demand_t,
                 external_constraint_supply_t, electricity_price):
        self.name = name
        self.grid_electricity_demand_t = grid_electricity_demand_t
        self.peak_grid_cap = peak_grid_cap
        self.external_constraint_demand_t = external_constraint_demand_t
        self.external_constraint_supply_t = external_constraint_supply_t
        self.electricity_price = electricity_price
        self.load_profile = pd.DataFrame()  # Store time-dependent data

    def update_load_profile(self, load_profile_df):
        """Updates the load profile for the electrical grid."""
        self.load_profile = load_profile_df

    def get_constraints(self, time_step):
        """Retrieve grid constraints at a specific time step."""
        row = self.load_profile.loc[self.load_profile['time'] == time_step * 1]
        if not row.empty:
            return row['external_constraint_supply_t'].values[0], row['external_constraint_demand_t'].values[0]
        else:
            return None, None

class SharedEnergyStorage:
    """Represents a shared energy storage unit."""
    def __init__(self, name, medium, energy_capacity, max_charge_rate, max_discharge_rate,
                 storage_efficiency, storage_type, initial_storage, minimum_level, maximum_level):
        self.name = name
        self.medium = medium
        self.energy_capacity = energy_capacity
        self.max_charge_rate = max_charge_rate
        self.max_discharge_rate = max_discharge_rate
        self.storage_efficiency = storage_efficiency
        self.type = storage_type
        self.current_storage = initial_storage * energy_capacity  # Initial SOC
        self.minimum_level = minimum_level
        self.maximum_level = maximum_level
        self.load = 0
        self.load_mutation = 0
        self.activity = "idle"
        self.used_this_step = False
        self.charge_left_this_step = max_charge_rate
        self.discharge_left_this_step = max_discharge_rate

    # def load(self): #unsure, not needed now.
    #     """Returns the current load contribution of this storage unit."""
    #     return self.current_storage if self.activity in ["discharge"] else -self.load_mutation

    def reset_usage(self):
        """Reset usage flag for the current time step."""
        self.used_this_step = False
        self.activity = "idle"
        self.charge_left_this_step = self.max_charge_rate
        self.discharge_left_this_step = self.max_discharge_rate
        # self.load = 0
        # self.load_mutation = 0

    def charge(self, flex_required):
        """Charge the storage to absorb excess energy. Flex required is a positive value"""
        if flex_required <= 0:
            return 0, 0  # Nothing to charge, no mutation in load

        charge_amount = min(
            self.max_charge_rate / self.storage_efficiency,  # Max charge limit considering efficiency
            flex_required,
            self.energy_capacity - self.current_storage  # Available space in storage
        )
        actual_charge = charge_amount * self.storage_efficiency
        self.current_storage += actual_charge
        self.load = charge_amount
        self.charge_left_this_step -= actual_charge
        self.discharge_left_this_step += actual_charge
        load_mutation = charge_amount  # the load_mutation is higher than the amount of charge due to losses.
        #print(self.name,"charge check", "self_load=", self.load, "current_storage=", self.current_storage, " charge_left_thiss", self.charge_left_this_step, "max_charge_rate=", self.max_charge_rate, "")
        return actual_charge, load_mutation

    def discharge(self, flex_required):
        """Discharge the storage to meet energy demand."""
        if flex_required >= 0:
            return 0, 0  # Nothing to discharge

        discharge_amount = -min(
            abs(self.max_discharge_rate),  # Max discharge limit   #not absolute
            abs(flex_required),
            self.current_storage  # Available energy in storage
        )
        self.current_storage += discharge_amount
        self.load = discharge_amount
        self.charge_left_this_step += discharge_amount
        self.discharge_left_this_step -= discharge_amount
        #print(" this is the load mutation: ", discharge_amount, "and should be negative")
        load_mutation = discharge_amount
        return discharge_amount, load_mutation  # Negative to indicate energy supplied to the grid

    def manage_flexibility(self, flex_required):
        """Manage charging or discharging to provide flexibility."""
        if flex_required < 0:
            # Discharge to meet demand
            storage_mutation, load_mutation = self.discharge(flex_required)
        elif flex_required > 0:
            # Charge to absorb excess
            storage_mutation, load_mutation = self.charge(flex_required)
        else:
            storage_mutation, load_mutation = 0, 0  # No flexibility required

        if storage_mutation != 0:
            self.activity = "load_management"
            self.used_this_step = True

        return storage_mutation, load_mutation

class ConversionUnit:
    def __init__(self,name, input_medium, output_medium_1, output_medium_2, conversion_rate_1, conversion_rate_2, min_input_capacity, max_input_capacity):

        self.name = name
        self.input_medium = input_medium
        self.output_medium_1 = output_medium_1
        self.output_medium_2 = output_medium_2
        self.conversion_rate_1 = conversion_rate_1
        self.conversion_rate_2 = conversion_rate_2
        self.min_input_capacity = min_input_capacity
        self.max_input_capacity = max_input_capacity
        self.input_amount = 0
        self.output_amount_medium_1 = 0
        self.output_amount_medium_2 = 0
        self.activity = "idle"
        self.used_this_step = False
    def reset_usage(self):
        """Reset usage flag for the current time step."""
        self.used_this_step = False
        self.activity = "idle"



class SinkSource:
    def __init__(self, name, medium, sell_price, buy_price, max_capacity):

        self.name = name
        self.medium = medium
        self.sell_price = sell_price
        self.buy_price = buy_price
        self.max_capacity = max_capacity
        self.mutation = 0
        self.current_sum = 0
        self.sum_cost = 0

    def update_sum(self):
        self.current_sum += self.mutation
        #self.sum_cost +=


def load_sink_source():
    # Create the SinkSource objects
    sinksources = [
        SinkSource(name="heatSinkSource", medium="heat", sell_price=2, buy_price=3, max_capacity=400),
        SinkSource(name="gasSinkSource", medium="gas", sell_price=4, buy_price=3, max_capacity=1000)
    ]
    return sinksources

# Loading Functions
def load_grid_users(filepath, base_dir):
    """Load GridUser objects from CSV file."""
    grid_users = []
    main_df = pd.read_csv(filepath)
    main_df.columns = main_df.columns.str.replace(' ', '').str.replace(',', '')

    for _, row in main_df.iterrows():
        user = GridUser(
            name=row['name'],
            electricity_demand_t=row['electricity_demand_t'],
            gas_energy_demand_t=row['gas_energy_demand_t'],
            heat_energy_demand_t=row['heat_energy_demand_t'],
            curtailment_cap=row['curtailment_cap'],
            curtailment_cost=row['curtailment_cost']
        )
        load_profile_file = row['electricity_demand_t']
        if pd.notna(load_profile_file) and isinstance(load_profile_file, str):
            load_profile_path = os.path.join(base_dir, load_profile_file)
            if os.path.isfile(load_profile_path):
                load_profile_df = pd.read_csv(load_profile_path)
                load_profile_df.columns = load_profile_df.columns.str.replace(' ', '').str.replace(',', '')

                # Ensure numerical columns are of float type
                load_profile_df['electric_load'] = load_profile_df['electric_load'].astype(float)
                if 'heat_load' in load_profile_df.columns:
                    load_profile_df['heat_load'] = load_profile_df['heat_load'].astype(float)

                user.update_load_profile(load_profile_df)
        grid_users.append(user)
    return grid_users

def load_electrical_grid(filepath, base_dir):
    """Load ElectricalGrid objects from CSV file."""
    electrical_grids = []
    main_df = pd.read_csv(filepath)
    main_df.columns = main_df.columns.str.replace(' ', '')

    for _, row in main_df.iterrows():
        grid = ElectricalGrid(
            name=row['name'],
            grid_electricity_demand_t=None,
            peak_grid_cap=None,
            external_constraint_demand_t=None,
            external_constraint_supply_t=None,
            electricity_price=None
        )
        load_profile_path = os.path.join(base_dir, str(row['electricity_price']))
        if pd.notna(row['electricity_price']) and os.path.isfile(load_profile_path):
            load_profile_df = pd.read_csv(load_profile_path)
            load_profile_df.columns = load_profile_df.columns.str.replace(' ', '')
            grid.update_load_profile(load_profile_df)
        electrical_grids.append(grid)
    return electrical_grids

def load_shared_energy_storage(filepath):
    """Load SharedEnergyStorage objects from CSV file."""
    storage_units = []
    storage_df = pd.read_csv(filepath)
    storage_df.columns = storage_df.columns.str.replace(' ', '')

    for _, row in storage_df.iterrows():
        storage = SharedEnergyStorage(
            name=row['name'],
            medium=row['medium'],
            energy_capacity=row['energy_capacity'],
            max_charge_rate=row['max_charge_rate'],
            max_discharge_rate=row['max_discharge_rate'],
            storage_efficiency=row['storage_efficiency'],
            storage_type=row['type'],
            initial_storage=row['initial_storage'],
            minimum_level=row['minimum_level'],
            maximum_level=row['maximum_level'],
        )
        storage_units.append(storage)
    return storage_units

def load_conversion_units(filepath):
    """Load ConversionUnit objects from CSV file."""
    conversion_units = []
    storage_df = pd.read_csv(filepath)

    for _, row in storage_df.iterrows():
        conversion_unit = ConversionUnit(
            name=row['name'],
            input_medium=row['input_medium'],
            output_medium_1=row['output_medium_1'],
            output_medium_2=row['output_medium_2'],
            conversion_rate_1=row['conversion_rate_1'],
            conversion_rate_2=row['conversion_rate_2'],
            min_input_capacity=row['min_input_capacity'],
            max_input_capacity=row['max_input_capacity']
        )
        conversion_units.append(conversion_unit)
    return conversion_units

