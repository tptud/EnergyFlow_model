import pandas as pd, os, re

'''This code returns this input configuration for a certain run'''

def tidy_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Strip quotes, commas and surrounding blanks from every column name."""
    df = df.copy()
    df.columns = [
        re.sub(r'[,"\s]+$', "",   # strip trailing commas, quotes, spaces
               re.sub(r'^[,"\s]+', "", c))  # strip leading ditto
        for c in df.columns
    ]
    return df

def summarise_scenario(name, grid_user_csv="", storage_csv="", conv_csv=""):
    row = dict(
        Scenario=name,
        Curtailment_cap_percent="",
        Curtailment_cost_EUR_kWh="",
        Storage_cap_MWh="",
        Charge_Discharge_MW="",
        Storage_eff_percent="",
        Min_Max_SOC_percent="",
        Conv_rate1_percent="",
        Conv_rate2_percent="",
        Max_output_cap_kW="",
    )

    # ---------- GRID-USER INPUTS ---------------------------------------
    if grid_user_csv and os.path.isfile(grid_user_csv):
        try:
            gu = tidy_columns(pd.read_csv(grid_user_csv))
            if not gu.empty and {"name", "curtailment_cap"}.issubset(gu.columns):
                caps = [
                    f"{n}: {c}"
                    for n, c in zip(gu["name"].astype(str), gu["curtailment_cap"])
                    if pd.notna(c) and str(c) != ""
                ]
                row["Curtailment_cap_percent"] = "; ".join(caps)

            if not gu.empty and {"name", "curtailment_cost"}.issubset(gu.columns):
                costs = [
                    f"{n}: {c}"
                    for n, c in zip(gu["name"].astype(str), gu["curtailment_cost"])
                    if pd.notna(c) and str(c) != ""
                ]
                row["Curtailment_cost_EUR_kWh"] = "; ".join(costs)
        except pd.errors.EmptyDataError:
            pass

    # -------- storage ---------------------------------------------------
    if storage_csv and os.path.isfile(storage_csv):
        try:
            st_df = pd.read_csv(storage_csv)
            if not st_df.empty:
                st = st_df.iloc[0]
                row["Storage_cap_MWh"]     = st.get("energy_capacity", "")
                charge, discharge = st.get("max_charge_rate", ""), st.get("max_discharge_rate", "")
                row["Charge_Discharge_MW"] = f"{charge}/{discharge}" if charge or discharge else ""
                row["Storage_eff_percent"] = st.get("storage_efficiency", "")
                mn, mx = st.get("minimum_level", ""), st.get("maximum_level", "")
                row["Min_Max_SOC_percent"] = f"{mn}/{mx}" if mn or mx else ""
        except pd.errors.EmptyDataError:
            pass

    # -------- conversion ------------------------------------------------
    if conv_csv and os.path.isfile(conv_csv):
        try:
            cu_df = pd.read_csv(conv_csv)
            if not cu_df.empty:
                cu = cu_df.iloc[0]
                row["Conv_rate1_percent"] = cu.get("conversion_rate_1", "")
                row["Conv_rate2_percent"] = cu.get("conversion_rate_2", "")
                row["Max_output_cap_kW"]  = cu.get(
                    "max_input_capacity", cu.get("max_output_capacity", "")
                )
        except pd.errors.EmptyDataError:
            pass

    return row


# base folder
BASE = "Objectdata/GridUserdata/objectinfo"

scenarios = [
    ("S0 Dynamic grid + storage",
     f"{BASE}/GridUser 1-5 .csv",
     f"{BASE}/SharedEnergyStorage 3,5-7,9 .csv",
     f"{BASE}/ConversionUnit 1 - 8, 10.csv"),

    ("S1 Dynamic grid + curtailment & storage",
     f"{BASE}/GridUser 1-5 .csv",
     f"{BASE}/SharedEnergyStorage 3,5-7,9 .csv",
     f"{BASE}/ConversionUnit 1 - 8, 10.csv"),

    ("S2 Flex with electrification (RUN 6)",
     f"{BASE}/GridUser 6 - 8  A truck.csv",
     f"{BASE}/SharedEnergyStorage 3,5-7,9 .csv",
     f"{BASE}/ConversionUnit 1 - 8, 10.csv"),

    ("S2b Bigger storage variant (RUN 8)",
     f"{BASE}/GridUser 6 - 8  A truck.csv",
     f"{BASE}/SharedEnergyStorage 8 .csv",
     f"{BASE}/ConversionUnit 1 - 8, 10.csv"),

    ("S3 Fuel-cell conversion",
     f"{BASE}/GridUser 9-10 .csv",
     f"{BASE}/SharedEnergyStorage 3,5-7,9 .csv",
     f"{BASE}/ConversionUnit 9 .csv"),

    ("S4 Grid expansion (all-electric) – model not run", "", "", ""),
]

df_inputs = pd.DataFrame([summarise_scenario(*s) for s in scenarios])

try:
    import ace_tools as tools
    tools.display_dataframe_to_user("Scenario input comparison", df_inputs)
except ImportError:
    print(df_inputs.to_string(index=True))

print(pd.DataFrame.to_csv(df_inputs, index=False))